package cm.library.utils;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Tools {
	public static int toInt(String arg) {
		try {
			return Integer.parseInt(arg);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return 1;
	}
	
	public static int toInt(String arg, int def) {
		try {
			return Integer.parseInt(arg);
		} catch (NumberFormatException e) {
			// e.printStackTrace();
		}
		return def;
	}

	public static String formatDateNow() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
		String date_string = sdf.format(date);
		return date_string;
	}

	public static String formatDateDay() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String date_string = sdf.format(date);
		return date_string;
	}
	
	public static String formatDateTimeNow() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String date_string = sdf.format(date);
		return date_string;
	}

	public static int[] randoms(int min, int max, int count) {
		int[] datas = new int[count];

		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		put(map, min, max, count);
		int index = 0;
		Set<Integer> set = map.keySet();
		Iterator<Integer> it = set.iterator();
		while (it.hasNext()) {
			datas[index++] = it.next();
		}
		return datas;
	}

	private static HashMap<Integer, Integer> put(HashMap<Integer, Integer> map,
			int min, int max, int count) {
		if (max - min < count) {
			for (int i = 0; i < max - min; i++) {
				map.put(min + i, min + i);
			}
			return map;
		}
		if (map.size() < count) {
			int random = random(min, max);
			map.put(random, random);
			put(map, min, max, count);
		} else {
			return map;
		}
		return map;
	}

	/** 产生随机数 */
	public static int random(int min, int max) {
		Random random = new Random();
		return random.nextInt(max) % (max - min + 1) + min;
	}

	public static String subStr(String src, int length) {
		if (null == src) {
			return src;
		}
		if (src.length() > length) {
			return src.substring(0, length) + "...";
		}
		return src;
	}

	public static String toUtf8(String str) {
		try {
			if (null != str && !"".equals(str)) {
				return new String(str.getBytes("ISO-8859-1"), "utf-8");
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return str;
	}
}